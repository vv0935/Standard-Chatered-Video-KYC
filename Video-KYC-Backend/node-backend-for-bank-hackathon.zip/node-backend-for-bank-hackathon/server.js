const express = require('express')
const mongoose = require('mongoose')
const UserModel = require('./models/User');
const routes = require('./routes/routes');

const app = express()
app.use(express.json())
app.use(express.urlencoded({extended: false}))

//routes
app.use(routes);


mongoose.set("strictQuery", false)
mongoose.
connect('mongodb+srv://admin:admin@cluster0.6ummazc.mongodb.net/Node-API?retryWrites=true&w=majority&appName=Cluster0')
.then(() => {
    console.log('connected to MongoDB')
    app.listen(3000, ()=> {
        console.log(`Node API app is running on port 3000`)
    });
}).catch((error) => {
    console.log(error)
})